CREATE TABLE `properties` (
  `property_id PK` INT NOT NULL AUTO_INCREMENT,
  `address` VARCHAR(255) NOT NULL,
  `type` VARCHAR(255) NOT NULL,
  `price` DECIMAL(10, 2) NOT NULL COMMENT 'Стоимость аренды (10 знаков, 2 после запятой)',
  PRIMARY KEY (`property_id PK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Создание таблицы для агентов с указанием движка и кодировки
CREATE TABLE `agents` (
  `agent_id PK` INT NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(255) NOT NULL,
  `commission_rate` DECIMAL(10, 2) NOT NULL COMMENT 'Комиссионные агента в деньгах (10 знаков, 2 после запятой)',
  PRIMARY KEY (`agent_id PK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `properties` (`address`, `type`,`price`) VALUES ('Московский проспект 75, 38', 'Офис', 90000);
INSERT INTO `properties` (`address`, `type`,`price`) VALUES ('Ярославский проспект 20', 'Офис', 98500);
INSERT INTO `properties` (`address`, `type`,`price`) VALUES ('Большая октябрьская улица 29', 'Квартира', 150000);
INSERT INTO `properties` (`address`, `type`,`price`) VALUES ('Улица Лисицана 25', 'Офис', 35000);
INSERT INTO `properties` (`address`, `type`,`price`) VALUES ('Федоровская улица 10, д5', 'Квартира', 52000);

-- Заполнение таблицы 'agents'
INSERT INTO `agents` (`full_name`, `commission_rate`) VALUES ('Иванов Петр', 17000);
INSERT INTO `agents` (`full_name`, `commission_rate`) VALUES ('Борисов Юра', 15000);
INSERT INTO `agents` (`full_name`, `commission_rate`) VALUES ('Самойлова Юля', 20000);
INSERT INTO `agents` (`full_name`, `commission_rate`) VALUES ('Масленникова Елизавета', 25000);
INSERT INTO `agents` (`full_name`, `commission_rate`) VALUES ('Веселая Анна', 11000);

SELECT * FROM properties WHERE type = 'Квартира'
